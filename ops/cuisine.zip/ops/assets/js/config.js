var krms_config ={
	'ApiUrl' : "https://cuisine.je/merchantapp/api",
	'SoundUrl': "file:///android_asset/www/audio/fb-alert.mp3",
	'DialogDefaultTitle' : "Cuisine",
	'pushNotificationSenderid' : "306047836229",
	'APIHasKey' : "db03847be0c7a3fb303f70f30520225c"
};
